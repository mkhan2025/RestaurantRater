package com.csc396.restaurantrater;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;

import com.csc396.restaurantrater.databinding.ActivityViewReviewsBinding;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ViewReviewsActivity extends AppCompatActivity {

    private ActivityViewReviewsBinding binding;
    private ArrayList<Review> myReviews = new ArrayList<Review>();
    private AdapterView.OnItemClickListener listViewReview_onItemClickListener = new AdapterView.OnItemClickListener(){

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String date = myReviews.get(position).getReviewDate();
            String time = myReviews.get(position).getReviewTime();
            AlertDialog.Builder myBuilder = new AlertDialog.Builder(ViewReviewsActivity.this);
            myBuilder.setTitle("Review Details")
                    .setMessage("The review was created on " + date + "at" + time);
            AlertDialog myDialog = myBuilder.create();
            myDialog.show();

        }
    };
    private View.OnClickListener button_add_review_clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent myIntent = new Intent(ViewReviewsActivity.this, AddReviewActivity.class);
            startActivity(myIntent);
        }
    };
    public void onRestart(){
        super.onRestart();
        readFile();
        onCreateSetUp();    }

    public void readFile(){
        File myFile = new File(getFilesDir(),"reviews.csv");
        try(Scanner myScanner = new Scanner(myFile)){
            while(myScanner.hasNextLine()){
                String line =  myScanner.nextLine();
                String [] lineData = line.split(",");
                Review review = new Review(lineData[0], lineData[1], lineData[2], lineData[3], Integer.valueOf(lineData[4]), Integer.valueOf(lineData[5]));
                myReviews.add(review);

            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    public void onCreateSetUp(){
        CustomAdapter myAdapter = new CustomAdapter(this, myReviews);
        binding.listviewReviews.setAdapter(myAdapter);
        binding.listviewReviews.setOnItemClickListener(listViewReview_onItemClickListener);
        binding.buttonAddReview.setOnClickListener(button_add_review_clickListener);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewReviewsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        readFile();
        onCreateSetUp();
    }

}