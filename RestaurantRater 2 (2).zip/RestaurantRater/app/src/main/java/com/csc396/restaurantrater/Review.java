package com.csc396.restaurantrater;

public class Review {
    private String resName;
    private String reviewDate;
    private String reviewTime;
    private String mealType;
    private int restaurantRating;
    private int isFavorite;

    public Review(String resName, String reviewDate, String reviewTime, String mealType, int restaurantRating, int isFavorite) {
        this.resName = resName;
        this.reviewDate = reviewDate;
        this.reviewTime = reviewTime;
        this.mealType = mealType;
        this.restaurantRating = restaurantRating;
        this.isFavorite = isFavorite;
    }

    public String getResName() {
        return resName;
    }

    public String getReviewDate() {
        return reviewDate;
    }

    public String getReviewTime() {
        return reviewTime;
    }

    public String getMealType() {
        return mealType.toString();
    }

    public int  getRestaurantRating() {
        return restaurantRating;
    }

    public int getIsFavorite() {
        return isFavorite;
    }

    @Override
    public String toString(){
        String reviewStringRep = getResName() + "," + getReviewDate() + "," + getReviewTime() + "," + getMealType() + "," + Integer.valueOf(getRestaurantRating()) + "," + Integer.valueOf(getIsFavorite())+"\n";
        return reviewStringRep;
    }
}
