package com.csc396.restaurantrater;

import android.content.Context;
import android.content.pm.LauncherActivityInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.List;

public class CustomAdapter extends BaseAdapter {

    private Context context;
    private List<Review> readReviews;

    public CustomAdapter(Context context, List<Review> readReviews) {
        this.context = context;
        this.readReviews = readReviews;
    }

    @Override
    public int getCount() {
        return readReviews.size();
    }


    @Override
    public Object getItem(int position) {
        return readReviews.get(position);
    }


    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.listview_review_rows, parent, false);
        }
        Review thisReview = readReviews.get(position);
        TextView restaurantName = convertView.findViewById(R.id.textView_restaurant_name);
        RatingBar isFavorite = convertView.findViewById(R.id.ratingBar_isFavorite);
        RadioButton breakfast = convertView.findViewById(R.id.radioButton_breakfast);
        RadioButton lunch = convertView.findViewById(R.id.radioButton_lunch);
        RadioButton dinner = convertView.findViewById(R.id.radioButton_dinner);
        ProgressBar restaurantRating = convertView.findViewById(R.id.progressBar_restaurant_rating);
        RadioGroup restaurantMeal = convertView.findViewById(R.id.radiogroup_meals);

        restaurantName.setText(thisReview.getResName());
        restaurantRating.setProgress(thisReview.getRestaurantRating());
        switch (thisReview.getIsFavorite()){
            case 0:
                isFavorite.setProgress(2);
                break;

            case 1:
                isFavorite.setProgress(0);
                break;
        }

        switch(thisReview.getMealType()){
            case "Breakfast":
                breakfast.setChecked(true);
                break;

            case "Lunch":
                lunch.setChecked(true);
                break;

            case "Dinner":
                dinner.setChecked(true);
                break;

        }


        return convertView;

    }
}
