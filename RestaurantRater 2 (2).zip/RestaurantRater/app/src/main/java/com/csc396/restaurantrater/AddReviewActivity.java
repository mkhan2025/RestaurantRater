package com.csc396.restaurantrater;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;

import com.csc396.restaurantrater.databinding.ActivityAddReviewBinding;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

public class AddReviewActivity extends AppCompatActivity {

    private ActivityAddReviewBinding binding;
    private View.OnClickListener button_add_review_clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String resName = binding.edittextRestaurantName.getText().toString();
            String date = binding.edittextReviewDate.getText().toString();
            String time = binding.edittextReviewTime.getText().toString();
            String meal = getMeal(binding.radiogroupMeals.getCheckedRadioButtonId());
            int isFavorite;
            int resRating = binding.seekbarRating.getProgress();
            if (binding.checkboxFavorite.isChecked()){
                isFavorite = 1;
            }
            else{
                isFavorite = 0;
            }
            Review userReview = new Review(resName, date, time, meal, resRating,isFavorite);
            try {
//                File myFile = new File(getFilesDir(), "review.csv");
                FileWriter myWriter = new FileWriter("data/data/com.csc396.restaurantrater/files/reviews.csv", true);
//                myWriter.write(resName+","+date+","+time+","+ meal+ ","+Integer.valueOf(resRating)+","+ Integer.valueOf(isFavorite) +"\n");
                myWriter.write(userReview.toString());
                myWriter.close();
            }


            catch(IOException e){
                e.printStackTrace();
            }
            finish();
        }
    };

    public String getMeal(int id){
        String mealType;
        if (id == R.id.radio_breakfast){
            mealType = "Breakfast";
        }
        else if (id == R.id.radio_lunch){
            mealType = "Lunch";
        }
        else if (id == R.id.radio_dinner){
            mealType = "Dinner";
        }
        else{
            mealType = "An error occured";
        }
        return mealType;
    }

    private View.OnClickListener edit_date_clickListener = new View.OnClickListener(){

        @Override
        public void onClick(View v) {
            Calendar myCalender = Calendar.getInstance();
            int year = myCalender.get(Calendar.YEAR);
            int month = myCalender.get(Calendar.MONTH);
            int day = myCalender.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    binding.edittextReviewDate.setText(String.valueOf(month +1 ) + "/" + String.valueOf(dayOfMonth) + "/" + String.valueOf(year));

                }
            };
            DatePickerDialog myDatePicker = new DatePickerDialog(AddReviewActivity.this, dateSetListener, year, month, day);
            myDatePicker.show();
        }
    };
    private View.OnClickListener edit_time_clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Calendar myCalender = Calendar.getInstance();
            int hour = myCalender.get(Calendar.HOUR);
            int minutes = myCalender.get(Calendar.MINUTE);
            TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    String totalMinutes;
                    if(minute < 10){
                        totalMinutes = "0" + String.valueOf(minute);
                    }
                    else{
                        totalMinutes = String.valueOf(minute);
                    }
                    if (hourOfDay < 12 && hourOfDay!= 0){
                        binding.edittextReviewTime.setText(String.valueOf(hourOfDay) + ":" + totalMinutes + "AM");
                    }
                    else if (hourOfDay > 12){
                        binding.edittextReviewTime.setText(String.valueOf(hourOfDay - 12) + ":" + totalMinutes + "PM");
                    }
                    else if (hourOfDay == 12){
                        binding.edittextReviewTime.setText(String.valueOf(hourOfDay) + ":" + totalMinutes + "PM");
                    }
                    else{
                        binding.edittextReviewTime.setText(String.valueOf(hourOfDay) + ":" + totalMinutes + "AM");
                    }
                }
            };
            TimePickerDialog myTimePicker = new TimePickerDialog(AddReviewActivity.this, timeSetListener, hour, minutes, false);
            myTimePicker.show();
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddReviewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Intent myIntent = getIntent();
        binding.edittextReviewDate.setOnClickListener(edit_date_clickListener);
        binding.edittextReviewTime.setOnClickListener(edit_time_clickListener);
        binding.buttonAddReview.setOnClickListener(button_add_review_clickListener);

    }
}